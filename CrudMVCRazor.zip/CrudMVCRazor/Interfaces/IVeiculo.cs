﻿using CrudMVCRazor.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CrudMVCRazor.Interfaces
{
    interface IVeiculo
    {
        void CadastrarVeiculoNoBanco(Veiculo veiculo);

        List<Veiculo>ListarVeiculo();

        Veiculo AtualizarVeiculo(Veiculo veiculo);

        Veiculo BuscarPorId(int id);

        Veiculo RemoverVeiculo(int id);
    }
}