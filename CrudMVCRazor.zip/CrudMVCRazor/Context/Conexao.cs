﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace CrudMVCRazor.Context
{
    public class Conexao
    {
        private static string ConnStr = @"Data Source=LAB107801\MSSQLSERVERTH;Initial Catalog=tsukamotors;Integrated Security=True";

        public static SqlConnection GetConnection()
        {
            var conn = new SqlConnection(ConnStr);
            return conn;
        }

    }
}