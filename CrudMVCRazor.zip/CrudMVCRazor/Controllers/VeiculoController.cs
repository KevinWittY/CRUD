﻿using CrudMVCRazor.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CrudMVCRazor.Controllers
{
    [Route("Veiculo")] // Define a rota que será solicitada
    public class VeiculoController : Controller
    {
        Veiculo veiculoModel = new Veiculo();
        public IActionResult Index()
        {
            // Encaminha para a View
            // Exibir a lista de veículos cadastrados
            ViewBag.listaDeVeiculos = veiculoModel.ListarVeiculo();
            // A ViewBag é utilizada para enviarmos dados para as views
            return View();
        }

        [Route("CadastrarVeiculo")]
        public IActionResult CadastrarVeiculo()
        {
            // Exibir a tela de cadastro
            return View();
        }

        // Método para receber os dados do formulário
        [Route("Cadastro")]
        public IActionResult Cadastro(IFormCollection formulario)
        {
            Veiculo novoVeiculo = new Veiculo();
            novoVeiculo.Marca = formulario["marcaForm"];
            novoVeiculo.Modelo = formulario["modeloForm"];
            novoVeiculo.Cor = formulario["corForm"];
            novoVeiculo.Placa = formulario["placaForm"];

            novoVeiculo.CadastrarVeiculoNoBanco(novoVeiculo);
            return LocalRedirect("~/Veiculo");
        }
    }
}