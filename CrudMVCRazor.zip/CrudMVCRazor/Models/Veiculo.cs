﻿using CrudMVCRazor.Context;
using CrudMVCRazor.Interfaces;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace CrudMVCRazor.Models
{
    public class Veiculo : IVeiculo
    {
        public int Id { get; set; }
        public string Marca { get; set; }
        public string Modelo { get; set; }
        public string Cor { get; set; }
        public string Placa { get; set; }

        public Veiculo AtualizarVeiculo(Veiculo veiculo)
        {
            throw new NotImplementedException();
        }

        public Veiculo BuscarPorId(int id)
        {
            throw new NotImplementedException();
        }

        public void CadastrarVeiculoNoBanco(Veiculo veiculo)
        {
            // Conectar com o banco
            var connection = Conexao.GetConnection();
            // Abrir a conexão
            connection.Open();
            // Query com comando SQL
            var query = "insert into veiculos (veiculoMarca, veiculoModelo, veiculoCor, veiculoPlaca) values (@marca, @modelo, @cor, @placa)";
            var command = new SqlCommand(query, connection);
            command.Parameters.Add("@marca", SqlDbType.VarChar).Value = veiculo.Marca;
            command.Parameters.Add("@modelo", SqlDbType.VarChar).Value = veiculo.Modelo;
            command.Parameters.Add("@cor", SqlDbType.VarChar).Value = veiculo.Cor;
            command.Parameters.Add("@placa", SqlDbType.VarChar).Value = veiculo.Placa;
            command.ExecuteNonQuery();

            connection.Close();
        }

        public List<Veiculo> ListarVeiculo()
        {
            var connection = Conexao.GetConnection();
            connection.Open();
            var query = "select * from veiculos";
            var command = new SqlCommand(query, connection);
            var dataSet = new DataSet(); // Local para armazenar as tabelas da pesquisa
            var adapter = new SqlDataAdapter(command);
            adapter.Fill(dataSet); // Dados do adapter são inseridos no DataSet
            // Mais de uma tabela podem ser armazenadas no DataSet
            var rows = dataSet.Tables[0].Rows;

            // Pegar os dados do banco e armazenar em um objeto do tipo veículo
            // e colocar cada veículo em uma lista de veículos

            List<Veiculo> listaDeVeiculos = new List<Veiculo>();
            foreach (DataRow item in rows)
            {
                var colunas = item.ItemArray;
                Veiculo novoVeiculo = new Veiculo();
                novoVeiculo.Id = int.Parse(colunas[0].ToString());
                novoVeiculo.Marca = colunas[1].ToString();
                novoVeiculo.Modelo = colunas[2].ToString();
                novoVeiculo.Cor = colunas[3].ToString();
                novoVeiculo.Placa = colunas[4].ToString();

                listaDeVeiculos.Add(novoVeiculo);
            }

            connection.Close();
            return listaDeVeiculos;
        }

        public Veiculo RemoverVeiculo(int id)
        {
            throw new NotImplementedException();
        }
    }
}